package com.backend.prog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgApplicationTests {

	@Test
	void contextLoads() {
	}

}
